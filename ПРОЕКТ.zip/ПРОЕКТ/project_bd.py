# Импортируем все необходимые модули
import sqlite3
import sys

from PyQt6.QtWidgets import QApplication
from PyQt6.QtWidgets import QMainWindow, QTableWidgetItem
from PyQt6 import uic

from project_ui import Ui_GlaufGurlApp


class Main(QMainWindow, Ui_GlaufGurlApp):
    def __init__(self):
        # Загружаем дизайн
        super().__init__()
        uic.loadUi(r"bd/project.ui", self)

        # Загружаем базу данных
        self.con = sqlite3.connect(r"bd/clothes_db.sqlite")

        cur = self.con.cursor()

        self.cart = set()

        self.type_base = {'All': '%',
                          'Футболки': 'Футболка',
                          'Обувь': 'Обувь',
                          'Аксесуары': 'Аксесуары',
                          'Другое': 'Другое'}

        self.radio_base = [self.radio_button_group.itemAt(0).widget(),
                           self.radio_button_group.itemAt(1).widget(),
                           self.radio_button_group.itemAt(2).widget(),
                           self.radio_button_group.itemAt(3).widget(),
                           self.radio_button_group.itemAt(4).widget()]

        # Заполняем выпадающие списки пола и размера
        self.comboBox_sex.addItems(
            [item[0] for item in cur.execute("SELECT DISTINCT sex from clothes_table").fetchall()])
        self.comboBox_sex.addItem('All')
        self.comboBox_sex.setCurrentIndex(4)

        self.comboBox_size.addItems(
            [item[0] for item in cur.execute("SELECT DISTINCT size from clothes_table").fetchall()])
        self.comboBox_size.addItem('All')
        self.comboBox_size.setCurrentIndex(5)

        # Задаем действия кнопкам вывода с фильтрами и вывода всего каталога
        self.pushButton.clicked.connect(self.select_data)
        self.catalog.clicked.connect(self.show_all)

        # Задаем действия кнопкам покупки и работы с корзиной
        self.buy_button.clicked.connect(self.buy)
        self.cart_button.clicked.connect(self.get_cart)
        self.clear_cart.clicked.connect(self.clear)

        self.textEdit.setPlainText('')

        # Выводим Весь каталог
        self.show_all()

        self.radioButton.setChecked(True)

        self.insert_BLOB()

    def convertToBinaryData(self, filename):
        # Convert digital data to binary format
        with open(filename, 'rb') as file:
            blob_data = file.read()
        return blob_data

    def insert_BLOB(self):
        try:
            cur = self.con.cursor()
            product_photo = self.convertToBinaryData('plain_t.jpg')
            sqlite_insert_blob_query = """ INSERT INTO clothes_table
                                          (photo) VALUES (?)"""
            cur.execute(sqlite_insert_blob_query, (product_photo,))
            self.con.commit()
            cur.close()

        except sqlite3.Error as error:
            print("Failed to insert pictures", error)

    def show_all(self):
        # Задаем курсор
        cur = self.con.cursor()

        # Делаем выборку столбцов name, sex, size
        cat = cur.execute('SELECT id, name, sex, size, photo FROM clothes_table').fetchall()

        # Задаем размеры таблицы
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setRowCount(0)

        # Заполняем таблицу элементами
        for i, row in enumerate(cat):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))

        # Выводим количество доступных товаров
        self.status.setText(f'Найдено товаров: {len(cat)}')

    def find_checked_radiobutton(self, radiobuttons):
        # Находим нажатую кнопку среди выбора типа товара
        for items in radiobuttons:
            if items.isChecked():
                checked_button = items.text()
                return checked_button

    def select_data(self):
        # Получим результат запроса, который ввели в текстовое поле + фильтры
        name_x = self.textEdit.toPlainText()  # Запрос
        sex_x = self.comboBox_sex.currentText()  # Фильтр пола
        size_x = self.comboBox_size.currentText()  # Фильтр размеров
        type_x = self.type_base[self.find_checked_radiobutton(self.radio_base)]  # Фильтр типа товара

        # Делаем выборку с заданной фильтрацией
        if sex_x == 'All':
            sex_x = '%'
        if size_x == 'All':
            size_x = '%'
        res = self.con.cursor().execute(
            f"SELECT id, name, sex, size, photo FROM clothes_table WHERE name LIKE '%{name_x}%' and"
            f" sex like '{sex_x}' and size like '{size_x}' and type like '{type_x}'").fetchall()

        # Заполним размеры таблицы
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setRowCount(0)

        # Заполняем таблицу элементами
        for i, row in enumerate(res):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))

        # Указываем количество доступных товаров
        if res:  # Если таковые есть
            self.status.setText(f'Найдено товаров: {len(res)}')
        else:  # Если таковых нет
            self.status.setText(f'Извините, ничего не нашлось \nНайдено товаров: {len(res)}')

    def buy(self):
        # Занесем введенный пользователем id в корзину
        self.cart.add(self.buy_id.text())
        self.buy_id.setText('')

    def get_cart(self):
        self.status.setText(f'Корзина: \nНайдено товаров: {len(self.cart)}')
        cart_id = ', '.join(self.cart)
        res = self.con.cursor().execute(f"SELECT id, name, sex,"
                                        f" size FROM clothes_table WHERE id IN ({cart_id})").fetchall()

        # Заполним размеры таблицы
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setRowCount(0)

        # Заполняем таблицу элементами
        for i, row in enumerate(res):
            self.tableWidget.setRowCount(
                self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(
                    i, j, QTableWidgetItem(str(elem)))

    def clear(self):
        self.cart.clear()
        self.get_cart()


def main():
    app = QApplication(sys.argv)
    ex = Main()
    ex.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
